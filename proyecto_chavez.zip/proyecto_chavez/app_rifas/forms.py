from django import forms
from .models import Participante, Orden
import re

class ParticipanteForm(forms.ModelForm):
    class Meta:
        model = Participante
        fields = '__all__'

class OrdenForm(forms.ModelForm):
    class Meta:
        model = Orden
        fields = ['estado', 'metodo_pago']  # Excluido numeros_favoritos

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def clean_numeros_favoritos(self):
        data = self.cleaned_data.get('numeros_favoritos', '')
        cantidad = self.cantidad

        numeros = [n.strip() for n in data.split(',') if n.strip()]

        if cantidad and len(numeros) != cantidad:
            raise forms.ValidationError(f"Debe ingresar exactamente {cantidad} números.")

        for n in numeros:
            if not re.fullmatch(r'\d{6}', n):
                raise forms.ValidationError(f"El número '{n}' no tiene exactamente 6 dígitos.")

        if len(set(numeros)) != len(numeros):
            raise forms.ValidationError("Los números no deben repetirse.")

        return numeros

