from django.shortcuts import render, redirect
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.contrib import messages
from .forms import ParticipanteForm, OrdenForm
from .models import Orden, MensajeSorteo, NumeroSeleccionado, Numero, SliderImagen
from django.views.decorators.csrf import csrf_exempt

# Vista principal
def home(request):
    mensaje = MensajeSorteo.objects.first()
    slider_imagenes = SliderImagen.objects.filter(activo=True)

    return render(request, 'app_rifas/home.html', {
        'mensaje': mensaje,
        'slider_imagenes': slider_imagenes
    })

# Vista para crear el pedido (registro inicial)
def crear_pedido(request):
    cantidad = int(request.GET.get("cantidad", 1))  # valor desde el botón Comprar

    if request.method == 'POST':
        participante_form = ParticipanteForm(request.POST)
        orden_form = OrdenForm(request.POST)

        # Obtener números favoritos desde el campo oculto
        numeros_str = request.POST.get('numeros_favoritos', '')
        numeros = [n.strip() for n in numeros_str.split(',') if n.strip()]

        if participante_form.is_valid() and orden_form.is_valid():
            # Validaciones de los números
            if len(numeros) != cantidad:
                orden_form.add_error(None, f"Debe ingresar exactamente {cantidad} números.")
            elif any(len(n) != 6 or not n.isdigit() for n in numeros):
                orden_form.add_error(None, "Todos los números deben tener exactamente 6 dígitos.")
            elif len(set(numeros)) != len(numeros):
                orden_form.add_error(None, "Los números no deben repetirse.")
            else:
                # Guardar datos si todo está correcto
                participante = participante_form.save()
                orden = orden_form.save(commit=False)
                orden.participante = participante
                orden.fecha = timezone.now()
                orden.total = 0  # Ajusta si manejas precios
                orden.save()

                for numero in numeros:
                    NumeroSeleccionado.objects.create(orden=orden, numero=numero)

                return redirect('detalle_pedido', orden.id)

    else:
        participante_form = ParticipanteForm()
        orden_form = OrdenForm()

    return render(request, 'app_rifas/crear_pedido.html', {
        'participante_form': participante_form,
        'orden_form': orden_form,
        'cantidad_maxima': cantidad
    })

# Vista para ver el detalle del pedido y simular pago
def detalle_pedido(request, pedido_id):
    pedido = get_object_or_404(Orden, pk=pedido_id)
    numeros = NumeroSeleccionado.objects.filter(orden=pedido)

    return render(request, 'app_rifas/detalle_pedido.html', {
        'pedido': pedido,
        'numeros': numeros,
    })

# Vista para simular el pago (registrar la compra)
def simular_pago(request, orden_id):
    orden = get_object_or_404(Orden, id=orden_id, estado='pendiente')

    if request.method == 'POST' or request.method == 'GET':
        # Cambiar estado a pagado
        orden.estado = 'pagado'
        orden.save()

        # Marcar los números como vendidos
        numeros_seleccionados = NumeroSeleccionado.objects.filter(orden=orden)
        for seleccionado in numeros_seleccionados:
            numero = int(seleccionado.numero)

            numero_obj, creado = Numero.objects.get_or_create(
                numero=numero,
                rifa__isnull=False,  # Puedes ajustar este filtro según la lógica real
                defaults={
                    'comprado': True,
                    'participante': orden.participante,
                    'orden': orden,
                    'fecha_compra': timezone.now()
                }
            )

            if not creado:
                numero_obj.comprado = True
                numero_obj.participante = orden.participante
                numero_obj.orden = orden
                numero_obj.fecha_compra = timezone.now()
                numero_obj.save()

        # Eliminar selección temporal
        numeros_seleccionados.delete()

        messages.success(request, f"El pago de la orden #{orden.id} fue simulado exitosamente.")

        return redirect('detalle_pedido', orden.id)

    return redirect('home')


