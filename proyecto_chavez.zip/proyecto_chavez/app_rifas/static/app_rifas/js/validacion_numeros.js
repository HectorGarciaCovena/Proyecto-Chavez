document.addEventListener("DOMContentLoaded", () => {
    const input = document.getElementById("numeroInput");
    const agregarBtn = document.getElementById("agregarNumeroBtn");
    const lista = document.getElementById("listaNumeros");
    const campoOculto = document.getElementById("numerosFavoritosInput");
    const errorDiv = document.getElementById("errorNumeros");
    const enviarBtn = document.getElementById("enviarPedidoBtn");

    const maxCantidad = parseInt(agregarBtn.dataset.max) || 1;
    const numeros = new Set();

    const form = document.querySelector("form");

    function actualizarCampoOculto() {
        const numerosArray = Array.from(numeros);
        campoOculto.value = numerosArray.join(",");

        if (numerosArray.length >= maxCantidad) {
            input.disabled = true;
            agregarBtn.disabled = true;
            errorDiv.textContent = "Límite alcanzado: no puedes agregar más números.";
        } else {
            input.disabled = false;
            agregarBtn.disabled = false;
            errorDiv.textContent = "";
        }

        validarFormularioCompleto();
    }

    function validarFormularioCompleto() {
        const camposRequeridos = [
            ...form.querySelectorAll('input[required], select[required], textarea[required]'),
            ...form.querySelectorAll('input[name$="nombre"], input[name$="apellido"], input[name$="email"], input[name$="telefono"], input[name$="direccion"], input[name$="ciudad"], input[name$="provincia"], input[name$="pais"]'),
            form.querySelector('select[name$="metodo_pago"]')
        ];

        const numerosCompletos = numeros.size === maxCantidad;
        const camposLlenos = camposRequeridos.every(field => field && field.value.trim() !== "");

        enviarBtn.disabled = !(numerosCompletos && camposLlenos);
    }

    agregarBtn.addEventListener("click", () => {
        const valor = input.value.trim();

        if (!/^\d{6}$/.test(valor)) {
            errorDiv.textContent = "El número debe tener exactamente 6 dígitos numéricos.";
            return;
        }

        if (numeros.has(valor)) {
            errorDiv.textContent = "Este número ya fue agregado.";
            return;
        }

        if (numeros.size >= maxCantidad) {
            errorDiv.textContent = `Solo puedes agregar hasta ${maxCantidad} números.`;
            return;
        }

        numeros.add(valor);
        const li = document.createElement("li");
        li.className = "list-group-item d-flex justify-content-between align-items-center";
        li.textContent = valor;

        const btnEliminar = document.createElement("button");
        btnEliminar.className = "btn btn-sm btn-danger";
        btnEliminar.textContent = "Eliminar";
        btnEliminar.addEventListener("click", () => {
            numeros.delete(valor);
            lista.removeChild(li);
            actualizarCampoOculto();
        });

        li.appendChild(btnEliminar);
        lista.appendChild(li);

        input.value = "";
        actualizarCampoOculto();
    });

    // Revalidar si el usuario modifica campos manualmente
    form.addEventListener("input", validarFormularioCompleto);
    form.addEventListener("change", validarFormularioCompleto);

    // Debug en consola
    form.addEventListener("submit", (e) => {
        console.log("Enviando números favoritos:", campoOculto.value);
    });

    actualizarCampoOculto(); // Inicializa estado
});


